import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

@st.cache_data
def load_data():
    df = pd.read_excel("studentperfomancee.xlsx")
    df.columns = df.columns.str.strip()
    return df

df = load_data()

st.title("📊 Dashboard Analisis Faktor yang Mempengaruhi GPA Mahasiswa")
st.write("Dashboard ini menganalisis faktor yang sangat berpengaruh dengan nilai mahasiswa (GPA).")

df.drop_duplicates(inplace=True)
df.dropna(inplace=True)
df = df[(df['GPA'] >= 0) & (df['GPA'] <= 4)]

le = LabelEncoder()
for col in ['ParentalEducation', 'ParentalSupport']:
    if col in df.columns:
        df[col] = le.fit_transform(df[col])

y = df['GPA']
X = df.drop(['GPA', 'StudentID'], axis=1, errors='ignore')

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)


import numpy as np
y_class = pd.cut(y, bins=[0,2,3,4], labels=["Low","Medium","High"])

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_class, test_size=0.2, random_state=42)
clf = RandomForestClassifier(random_state=42)
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)


st.subheader("Distribusi GPA")

fig, ax = plt.subplots()
sns.histplot(df['GPA'], kde=True, bins=20, ax=ax)
plt.xlabel("GPA")
plt.ylabel("Frekuensi")
st.pyplot(fig)


feat_importance = pd.DataFrame({
    'feature': X.columns,
    'importance': clf.feature_importances_
}).sort_values(by='importance', ascending=False)

st.subheader("Faktor Paling Berpengaruh terhadap GPA")
fig3, ax3 = plt.subplots()
sns.barplot(x='importance', y='feature', data=feat_importance, ax=ax3)
st.pyplot(fig3)

st.subheader("Classification Report")
report = classification_report(y_test, y_pred, output_dict=True)
st.dataframe(pd.DataFrame(report).transpose())


main_factor = feat_importance.iloc[0]['feature']
st.subheader("Insight & Finding")
st.write(f"Faktor yang paling berpengaruh terhadap GPA mahasiswa adalah **{main_factor}**. Hal ini menegaskan bahwa **{main_factor}** yang konsisten sangat penting bagi tinggi rendahnya GPA mahasiswa. \n")
st.write(f"Hasil klasifikasi membagi nilai siswa ke dalam tiga kategori: Rendah, Sedang, dan Tinggi. Kategorisasi ini didasarkan pada GPA, yang mencerminkan adanya rentang capaian akademik di antara siswa.")
st.write(f"Analisis data menekankan bahwa kehadiran merupakan faktor utama dalam menentukan performa akademik siswa. Distribusi siswa dalam kategori Rendah, Sedang, dan Tinggi menunjukkan adanya spektrum kemampuan akademik yang luas, serta kebutuhan akan intervensi khusus bagi siswa dengan GPA rendah.")
st.write(f"Rekomendasi: Untuk mengatasi masalah absensi yang berpengaruh terhadap GPA, strategi yang dapat diterapkan antara lain: \n"   
    
f"""
    1. Program Intervensi Dini: Mengidentifikasi siswa yang berisiko memiliki kehadiran buruk sejak awal tahun ajaran dan memberikan dukungan yang diperlukan.

    2. Keterlibatan Orang Tua: Memperkuat komunikasi dengan orang tua untuk memahami dan mengatasi hambatan kehadiran siswa.

    3. Program Insentif: Memberikan penghargaan atau pengakuan bagi siswa dengan kehadiran konsisten untuk meningkatkan motivasi.

    4. Dukungan Belajar Tambahan: Menyediakan bimbingan belajar atau les tambahan bagi siswa dengan GPA rendah agar dapat memperbaiki performa akademiknya.

    5. Tinjauan Kebijakan: Mengevaluasi kebijakan sekolah terkait absensi agar tidak secara tidak langsung memperburuk tingkat kehadiran siswa.

Rekomendasi ini bertujuan untuk secara langsung mengatasi permasalahan absensi yang memengaruhi GPA serta memberikan dukungan tepat sasaran bagi siswa yang membutuhkan, sehingga dapat meningkatkan performa akademik secara keseluruhan dan memperkecil kesenjangan antara kategori Rendah, Sedang, dan Tinggi.""")


